#include "linked_list.h"

/** add_at_index
 * 
 * Creates and adds a node at the specified index in the provided linked list.
 * 
 * @param head Pointer to the list which will be added to
 * @param val Val attribute of the node to be added
 * @param index Index in the linked list where the node will be added (0 indexed)
 * @return FAILURE if list is NULL, if malloc fails, or if index is invalid
 * SUCCESS otherwise.
*/
int add_at_index(LinkedList *list, int val, int index) {
    if (list == NULL)
        return FAILURE;

    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL)
        return FAILURE;
    newNode->val = val;

    if (index == 0) {
        newNode->next = list->head;
        list->head = newNode;
        return SUCCESS;
    } 

    if (index == 1 && list->head == NULL) {
        free(newNode);
        return FAILURE;
    }
    
    Node *prev = list->head;
    for (int i = 0; i < index - 1; i++) {
        if (prev == NULL) {
            free(newNode);
            return FAILURE;
        }
        prev = prev->next;
    }

    newNode->next = prev->next;
    prev->next = newNode;
    return SUCCESS;
}